﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class CharacterMovement : MonoBehaviour
{
    public float speed;
    public GameObject healthText;
    public float rotateSpeed;
    public float damageRate;
    public float health;
    public Animator animator;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        healthText.GetComponent<Text>().text = "Health: " + health;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W) && health > 0)
        {
            transform.position += transform.forward * speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.S) && health > 0)
        {
            transform.position += transform.forward * -speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.A) && health > 0)
        {
            transform.Rotate(new Vector3(0, Time.deltaTime * -rotateSpeed, 0));
        }

        if (Input.GetKey(KeyCode.D) && health > 0)
        {
            transform.Rotate(new Vector3(0, Time.deltaTime * rotateSpeed, 0));
        }

        if (Input.GetKeyDown(KeyCode.Space) && health > 0)
        {
            animator.SetTrigger("AttackTrigger");
        }

        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D))
        {
            animator.SetBool("IsWalkBool", true);
        }

        if (Input.anyKey == false && health > 0)
        {
            animator.SetBool("IsWalkBool", false);
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Fire")
        {
            health -= damageRate * Time.deltaTime;
            healthText.GetComponent<Text>().text = "Health: " + health;
        }

        if (health <= 0)
        {
            animator.SetTrigger("DeadTrigger");
        }
    }
}
